import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MapPin, Calendar, Utensils, Landmark } from "lucide-react";
import { useState, useEffect } from "react";

const carouselItems = [
  {
    title: "Festival de Teatro",
    description: "Del 10 al 12 de octubre, en el Cine Belgrano.",
    image: "/img/festival.jpg"
  },
  {
    title: "Feria de Sabores",
    description: "Descubrí la gastronomía local este domingo en Plaza 25 de Mayo.",
    image: "https://images.unsplash.com/photo-1600891964599-f61ba0e24092?fit=crop&w=600&h=300"
  },
  {
    title: "Maratón Ciudad de Rafaela",
    description: "Inscripciones abiertas para la carrera del 5 de noviembre.",
    image: "https://images.unsplash.com/photo-1508609349937-5ec4ae374ebf?fit=crop&w=600&h=300"
  }
];

export default function ViviRafaelaApp() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [showBubble, setShowBubble] = useState(false);

  const nextSlide = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % carouselItems.length);
  };

  const prevSlide = () => {
    setCurrentIndex((prevIndex) => (prevIndex - 1 + carouselItems.length) % carouselItems.length);
  };

  useEffect(() => {
    const interval = setInterval(nextSlide, 10000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const script = document.createElement("script");
    script.src = "https://chatbot.rafaela.gob.ar/widget.js";
    script.async = true;
    document.body.appendChild(script);

    const hasSeenBubble = sessionStorage.getItem("seenBubble");
    if (!hasSeenBubble) {
      const bubbleTimeout = setTimeout(() => {
        setShowBubble(true);
        sessionStorage.setItem("seenBubble", "true");
      }, 5000);
      return () => clearTimeout(bubbleTimeout);
    }
  }, []);

  const openRafiChat = () => {
    if (window?.RafiChat?.open) {
      window.RafiChat.open();
      setShowBubble(false);
    }
  };

  return (
    <div className="min-h-screen bg-white text-gray-800 relative">
      <header className="bg-orange-500 p-6 shadow-md">
        <div className="text-center mb-6">
          <h1 className="text-3xl font-bold text-white drop-shadow-md">Viví Rafaela</h1>
          <p className="text-sm text-white">Tu ciudad, tu historia, tu experiencia</p>
        </div>

        <div className="relative w-full overflow-hidden h-72 rounded-lg bg-white">
          <div
            className="flex transition-transform duration-700 ease-in-out"
            style={{ transform: `translateX(-${currentIndex * 100}%)` }}
          >
            {carouselItems.map((item, index) => (
              <div key={index} className="min-w-full flex-shrink-0 flex flex-col items-center p-4 bg-orange-400">
                <img
                  src={item.image}
                  alt={item.title}
                  className="rounded-lg mb-4 w-full h-40 object-cover"
                />
                <h2 className="text-xl font-semibold text-white">{item.title}</h2>
                <p className="text-sm text-white text-center">{item.description}</p>
              </div>
            ))}
          </div>
          <div className="absolute top-1/2 left-0 transform -translate-y-1/2 px-2">
            <Button onClick={prevSlide}>‹</Button>
          </div>
          <div className="absolute top-1/2 right-0 transform -translate-y-1/2 px-2">
            <Button onClick={nextSlide}>›</Button>
          </div>
        </div>
      </header>

      <main className="p-6 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card className="bg-orange-500 text-white shadow-lg">
          <CardContent className="flex flex-col items-center justify-center p-6 text-center">
            <Calendar className="w-12 h-12 text-white mb-2" />
            <h2 className="text-lg font-semibold">Eventos</h2>
            <p className="text-sm mb-4">Descubrí lo que está pasando en la ciudad</p>
            <Button variant="secondary">Ver más</Button>
          </CardContent>
        </Card>

        <Card className="bg-yellow-400 text-white shadow-lg">
          <CardContent className="flex flex-col items-center justify-center p-6 text-center">
            <Landmark className="w-12 h-12 text-white mb-2" />
            <h2 className="text-lg font-semibold">Experiencias Urbanas</h2>
            <p className="text-sm mb-4">Recorridos, cultura e historia local</p>
            <Button variant="secondary">Explorar</Button>
          </CardContent>
        </Card>

        <Card className="bg-teal-500 text-white shadow-lg">
          <CardContent className="flex flex-col items-center justify-center p-6 text-center">
            <Utensils className="w-12 h-12 text-white mb-2" />
            <h2 className="text-lg font-semibold">Gastronomía</h2>
            <p className="text-sm mb-4">Sabores auténticos de Rafaela</p>
            <Button variant="secondary">Conocer</Button>
          </CardContent>
        </Card>

        <Card className="bg-blue-500 text-white shadow-lg">
          <CardContent className="flex flex-col items-center justify-center p-6 text-center">
            <MapPin className="w-12 h-12 text-white mb-2" />
            <h2 className="text-lg font-semibold">Mapa Interactivo</h2>
            <p className="text-sm mb-4">Descubrí la ciudad en tu pantalla</p>
            <Button variant="secondary">Ver mapa</Button>
          </CardContent>
        </Card>
      </main>

      <footer className="bg-teal-800 text-white p-4 text-center">
        <p>© 2025 Viví Rafaela – Municipalidad de Rafaela</p>
      </footer>

      {showBubble && (
        <div
          className="fixed bottom-24 right-6 bg-white text-black text-sm px-4 py-2 rounded-xl shadow-lg animate-fade-in"
          onClick={openRafiChat}
          style={{ cursor: "pointer" }}
        >
          👋 ¡Hola! ¿Necesitás ayuda?
        </div>
      )}

      <button
        onClick={openRafiChat}
        className="fixed bottom-6 right-6 bg-white hover:bg-gray-100 border border-teal-600 rounded-full p-2 shadow-lg animate-bounce"
        aria-label="Abrir chat Rafi"
      >
        <img
          src="/img/rafi-icon.png"
          alt="Chat Rafi"
          className="w-12 h-12 object-contain"
          title="¿Necesitás ayuda?"
        />
      </button>
    </div>
  );
}
