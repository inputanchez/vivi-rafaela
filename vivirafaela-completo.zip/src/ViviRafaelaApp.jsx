import React from 'react';
import Slider from 'react-slick';
import RafiBot from './RafiBot';
import { CalendarDays, MapPinned, Utensils, Map } from 'lucide-react';

function ViviRafaelaApp() {
  const noticias = [
    { img: "https://www.rafaela.gob.ar/media/noticias/2024/11/noticia1.jpg", title: "Festival de Teatro Independiente 2025" },
    { img: "https://www.rafaela.gob.ar/media/noticias/2024/11/noticia2.jpg", title: "Nuevas obras en barrios" },
    { img: "https://www.rafaela.gob.ar/media/noticias/2024/11/noticia3.jpg", title: "Inauguración del Parque de la Innovación" },
    { img: "https://www.rafaela.gob.ar/media/noticias/2024/11/noticia4.jpg", title: "Convocatoria a emprendedores locales" },
  ];

  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: true,
    autoplay: true,
    autoplaySpeed: 5000
  };

  const iconMap = {
    Eventos: <CalendarDays size={20} className="inline mr-2" />,
    "Experiencias Urbanas": <MapPinned size={20} className="inline mr-2" />,
    Gastronomía: <Utensils size={20} className="inline mr-2" />,
    "Mapa Interactivo": <Map size={20} className="inline mr-2" />
  };

  const colorMap = {
    Eventos: "bg-[#F04E23]",
    "Experiencias Urbanas": "bg-[#0097A7]",
    Gastronomía: "bg-[#A0C42E]",
    "Mapa Interactivo": "bg-[#D98E04]"
  };

  return (
    <div>
      <header className="bg-[#FFCC00] p-10 shadow-xl text-center">
        <h1 className="text-5xl font-extrabold text-black font-nunito">VIVI RAFAELA</h1>
        <p className="text-lg mt-3 text-white italic">Rafaela, ciudad viva. Ciudad tuya.</p>
      </header>

      <section className="p-6">
        <h2 className="text-2xl font-bold mb-4 text-center">Noticias destacadas</h2>
        <Slider {...settings}>
          {noticias.map((n, i) => (
            <div key={i} className="px-4">
              <img src={n.img} alt={n.title} className="w-full h-64 object-cover rounded-lg shadow-md" />
              <p className="mt-2 text-center font-semibold">{n.title}</p>
            </div>
          ))}
        </Slider>
      </section>

      <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 p-6">
        {[
          "Eventos",
          "Experiencias Urbanas",
          "Gastronomía",
          "Mapa Interactivo"
        ].map((title, i) => {
          const isLink = title === "Mapa Interactivo";
          const commonClasses = \`w-full text-base flex items-center justify-center gap-2 mt-2 px-4 py-2 text-white rounded transition hover:opacity-90 \${colorMap[title]}\`;
          return (
            <div key={i} className="bg-slate-100 rounded-lg p-6 shadow hover:shadow-lg transition-all duration-700 ease-in-out transform hover:scale-105 opacity-0 animate-fadeIn">
              <h3 className="text-xl font-bold mb-4">{title}</h3>
              {isLink ? (
                <a
                  href="https://www.google.com/maps/place/Rafaela,+Santa+Fe/@-31.2514421,-61.5019536,13z"
                  target="_blank"
                  rel="noopener noreferrer"
                  className={commonClasses}
                >
                  {iconMap[title]} Ver más
                </a>
              ) : (
                <button className={commonClasses}>
                  {iconMap[title]} Ver más
                </button>
              )}
            </div>
          );
        })}
      </section>

      <footer className="bg-gray-100 text-center text-sm py-4 mt-10 border-t border-gray-300">
        © 2025 Municipalidad de Rafaela - Todos los derechos reservados.
      </footer>

      <RafiBot />
    </div>
  );
}

export default ViviRafaelaApp;
